package Utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


import Config.configuration;

public class Driver {
	
	public static WebDriver Instance =null;
	public static void Initialize(){
		
		if(Instance==null){
			System.out.println("Instancing Driver");
			if(configuration.cho.browser2.equalsIgnoreCase("ff"));
			Instance=new FirefoxDriver();
			
		}
		else if (configuration.cho.browser2.equalsIgnoreCase("ie"))
		{
			System.setProperty("webdriver.ie.driver","F:\\SeleniumJarFiles\\IEDriverServer.exe");
			Instance=new InternetExplorerDriver(); 
					
		}
		
		else if (configuration.cho.browser2.equalsIgnoreCase("Chrome"))
		
		{
			
			System.setProperty("webdriver.chrome.driver","F:\\SeleniumJarFiles\\chromedriver.exe");
			Instance=new ChromeDriver();
		
				
			 
		}
		
		Instance.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Instance.manage().window().maximize();
		
	}
	public static void close(){
		
		System.out.println("Instance Closing");
		Instance.close(); 
		Instance=null;
	}
}

