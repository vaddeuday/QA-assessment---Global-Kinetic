package Config;



public class configuration {
	
	public static class url{
		public static String app_url="http://yahoomail.com/";
	}
	

	public static class cho{
		public static String  browser2="ff";
	}
	
}
