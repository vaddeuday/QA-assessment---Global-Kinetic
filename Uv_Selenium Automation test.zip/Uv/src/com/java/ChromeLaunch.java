package com.java;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeLaunch {

	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","F:\\SeleniumJarFiles\\chromedriver.exe");
		ChromeDriver  driver=new ChromeDriver();
		driver.get("http://yahoomail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.findElement(By.id("login-username")).sendKeys("test.gk");
	    driver.findElement(By.id("login-signin")).click();
		
		driver.findElement(By.id("login-passwd")).sendKeys("June@2018");
		driver.findElement(By.id("login-signin")).click();

	}

}














