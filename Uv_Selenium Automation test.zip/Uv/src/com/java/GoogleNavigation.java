package com.java;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.server.browserlaunchers.Sleeper;

public class GoogleNavigation {

	public static void main(String[] args) 
	{
		FirefoxDriver driver=new FirefoxDriver();
		driver.get("http://yahoomail.com");
		driver.findElement(By.id("login-username")).sendKeys("test.gk");
		driver.findElement(By.id("login-signin")).click();
		Sleeper.sleepTightInSeconds(10);
		driver.findElement(By.id("login-passwd")).sendKeys("June@2018");
		driver.findElement(By.id("login-signin")).click();

	}

}

