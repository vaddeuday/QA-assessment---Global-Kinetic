package TestCases;


import org.openqa.selenium.By;
import org.openqa.selenium.server.browserlaunchers.Sleeper;
import org.testng.annotations.Test;

import Config.configuration;
import Utilities.Driver;
import Utilities.TestCase;



public class FirstTest extends TestCase {
	
	//Basic navigation and functionality
	@Test 
	public void Browser() {
		
		Driver.Instance.navigate().to(configuration.url.app_url);
	    Driver.Instance.findElement(By.id("login-username")).sendKeys("test.gk");
	    Driver.Instance.findElement(By.id("login-signin")).click();
	    Sleeper.sleepTightInSeconds(10);
	    Driver.Instance.findElement(By.id("login-passwd")).sendKeys("June@2018");
		Driver.Instance.findElement(By.id("login-signin")).click();
		
			
	}
	
		
	}
	




